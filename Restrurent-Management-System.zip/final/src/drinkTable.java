/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class drinkTable {
    String did, dname;
    int price;

    public drinkTable(String did, String dname, int price) {
        this.did = did;
        this.dname = dname;
        this.price = price;
    }
    
    public drinkTable(int price)
    {
        this.price = price;
    }
    
    public void setDid(String did) {
        this.did = did;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getDid() {
        return did;
    }

    public String getDname() {
        return dname;
    }

    public int getPrice() {
        return price;
    }
    
    
    
}

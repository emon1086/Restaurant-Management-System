
import static java.lang.Thread.sleep;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class takeOrder extends javax.swing.JFrame {

    /**
     * Creates new form takeOrder
     */
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    static int fdPrice,tp=0, own=0, count = 0;
    int sum = 0;
 
    public takeOrder() {
        initComponents();
        dates();
    }
    
    public void insertion(int own)
    {
        if(count==0)
        {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost/restaurant management system","root","");
                ps = con.prepareStatement("INSERT INTO `totalselling` VALUES(?,?)");
                ps.setString(1, jdt.getText());
                ps.setInt(2, own);
                ps.executeUpdate();
                count++;
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(takeOrder.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(takeOrder.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        else
        {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost/restaurant management system","root","");
                ps = con.prepareStatement("UPDATE `totalselling` SET `Total Sale`=? WHERE `Date`=?");
                ps.setInt(1, own);
                ps.setString(2, jdt.getText());
                ps.executeUpdate();
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(takeOrder.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(takeOrder.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void dates()
    {
        Date thisDate = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd");
        jdt.setText(sdf.format(thisDate));
    }
    
    
    public ArrayList<foodTable> ft()
    {
        ArrayList<foodTable> fa = new ArrayList<>();
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost/restaurant management system", "root","");
            
            
                ps = con.prepareStatement("SELECT * FROM `food`");
                rs = ps.executeQuery();
                foodTable f;
            
                while(rs.next())
                {
                    f = new foodTable(rs.getString("Food ID"),rs.getString("Name"), rs.getInt("Price"));
                    fa.add(f);
                }
            
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(takeOrder.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(takeOrder.class.getName()).log(Level.SEVERE, null, ex);
            }
            return fa;
        }
    
        public ArrayList<drinkTable> dt()
        {
            ArrayList<drinkTable> da = new ArrayList<>();
            
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost/restaurant management system", "root","");
            
            
                ps = con.prepareStatement("SELECT * FROM `drinks`");
                rs = ps.executeQuery();
                drinkTable d;
            
                while(rs.next())
                {
                    d = new drinkTable(rs.getString("Drinks ID"),rs.getString("Name"), rs.getInt("Price"));
                    da.add(d);
                }
            
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(takeOrder.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(takeOrder.class.getName()).log(Level.SEVERE, null, ex);
            }
            return da;
        }
        
        
        
    
    
    public void showInTable(String s)
    {
        
        if(s.equals("Food"))
        {
            ArrayList<foodTable> f = ft();
            Object row[] = new Object[3];
            DefaultTableModel table = (DefaultTableModel)fTable.getModel();
        
            for(int i = 0; i<f.size(); i++)
            {
                row[0]=f.get(i).getFid();
                row[1]=f.get(i).getName();
                row[2]=f.get(i).getPrice();
                table.addRow(row);
            }
        }
        else if(s.equals("Drinks"))
        {
            ArrayList<drinkTable> d = dt();
            Object row[] = new Object[3];
            DefaultTableModel table = (DefaultTableModel)dTable.getModel();
        
            for(int i = 0; i<d.size(); i++)
            {
                row[0]=d.get(i).getDid();
                row[1]=d.get(i).getDname();
                row[2]=d.get(i).getPrice();
                table.addRow(row);
            }
        }
    }
    
    public void showSearchedFood(ArrayList<foodTable> fl)
    {
        
            ArrayList<foodTable> f = fl;
            Object row[] = new Object[3];
            DefaultTableModel table = (DefaultTableModel)fTable.getModel();
            table.setRowCount(0);
            for(int i = 0; i<f.size(); i++)
            {
                row[0]=f.get(i).getFid();
                row[1]=f.get(i).getName();
                row[2]=f.get(i).getPrice();
                table.addRow(row);
            }
    }
    public void showSearchedDrinks(ArrayList<drinkTable> dl)
    {
        ArrayList<drinkTable> d = dl;
            Object row[] = new Object[3];
            DefaultTableModel table = (DefaultTableModel)dTable.getModel();
            table.setRowCount(0);
            for(int i = 0; i<d.size(); i++)
            {
                row[0]=d.get(i).getDid();
                row[1]=d.get(i).getDname();
                row[2]=d.get(i).getPrice();
                table.addRow(row);
            }
    }
    
    public void showAddFood(int p,ArrayList<foodTable> fl)
    {
        
            ArrayList<foodTable> f = fl;
            Object row[] = new Object[3];
            DefaultTableModel table = (DefaultTableModel)srcTable.getModel();
            //table.setRowCount(0);
            for(int i = 0; i<f.size(); i++)
            {
                row[0]=f.get(i).getFid();
                row[1]=f.get(i).getName();
                row[2]=p;
                table.addRow(row);
            }
    }
    public void showAddDrinks(int p,ArrayList<drinkTable> dl)
    {
        ArrayList<drinkTable> d = dl;
            Object row[] = new Object[3];
            DefaultTableModel table = (DefaultTableModel)srcTable.getModel();
            //table.setRowCount(0);
            for(int i = 0; i<d.size(); i++)
            {
                row[0]=d.get(i).getDid();
                row[1]=d.get(i).getDname();
                row[2]=p;
                table.addRow(row);
            }
    }
    
    public void AddTotalPrice()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/restaurant management system","root","");
            
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(takeOrder.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(takeOrder.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jdt = new javax.swing.JTextField();
        jScrollPane6 = new javax.swing.JScrollPane();
        jPanel15 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        foodBtn = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        fTable = new javax.swing.JTable();
        jSeparator3 = new javax.swing.JSeparator();
        jPanel10 = new javax.swing.JPanel();
        drinksBtn = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        dTable = new javax.swing.JTable();
        jPanel11 = new javax.swing.JPanel();
        Src = new javax.swing.JButton();
        txtSrc = new javax.swing.JTextField();
        quan = new javax.swing.JSpinner();
        aDD = new javax.swing.JButton();
        Rmv = new javax.swing.JButton();
        Bck = new javax.swing.JButton();
        Hme = new javax.swing.JButton();
        Rfrs = new javax.swing.JButton();
        category = new javax.swing.JComboBox<>();
        idTxt = new javax.swing.JTextField();
        cus = new javax.swing.JSpinner();
        jSeparator4 = new javax.swing.JSeparator();
        jScrollPane5 = new javax.swing.JScrollPane();
        srcTable = new javax.swing.JTable();
        jSeparator5 = new javax.swing.JSeparator();
        jPanel13 = new javax.swing.JPanel();
        sbmt = new javax.swing.JButton();
        jScrollPane7 = new javax.swing.JScrollPane();
        customer = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(255, 0, 0));

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        jButton1.setBackground(new java.awt.Color(0, 153, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/iconfinder_bacon_2693193.png"))); // NOI18N
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(255, 0, 0));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/iconfinder_cutlery_2693196.png"))); // NOI18N
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jdt.setEditable(false);
        jdt.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jdt, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 397, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jdt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel15.setBackground(new java.awt.Color(255, 102, 0));

        jPanel7.setBackground(new java.awt.Color(255, 102, 0));

        foodBtn.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        foodBtn.setText("Food");
        foodBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        foodBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                foodBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(29, Short.MAX_VALUE)
                .addComponent(foodBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(79, Short.MAX_VALUE)
                .addComponent(foodBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(75, 75, 75))
        );

        fTable.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        fTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Food ID", "Name", "Price"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane3.setViewportView(fTable);

        jPanel10.setBackground(new java.awt.Color(255, 102, 0));

        drinksBtn.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        drinksBtn.setText("Drinks");
        drinksBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        drinksBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drinksBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(drinksBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(25, 25, 25))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap(86, Short.MAX_VALUE)
                .addComponent(drinksBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(57, 57, 57))
        );

        dTable.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        dTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Drink ID", "Name", "Price"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane4.setViewportView(dTable);

        Src.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Src.setText("Search");
        Src.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Src.setEnabled(false);
        Src.setInheritsPopupMenu(true);
        Src.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SrcActionPerformed(evt);
            }
        });

        txtSrc.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        txtSrc.setEnabled(false);
        txtSrc.setInheritsPopupMenu(true);
        txtSrc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtSrcKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSrcKeyReleased(evt);
            }
        });

        quan.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        quan.setEnabled(false);
        quan.setInheritsPopupMenu(true);

        aDD.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        aDD.setText("Add");
        aDD.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        aDD.setEnabled(false);
        aDD.setInheritsPopupMenu(true);
        aDD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aDDActionPerformed(evt);
            }
        });

        Rmv.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Rmv.setText("Remove");
        Rmv.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Rmv.setEnabled(false);
        Rmv.setInheritsPopupMenu(true);

        Bck.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Bck.setText("Back");
        Bck.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Bck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BckActionPerformed(evt);
            }
        });

        Hme.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Hme.setText("Home");
        Hme.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Hme.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HmeActionPerformed(evt);
            }
        });

        Rfrs.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        Rfrs.setText("Refresh");
        Rfrs.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Rfrs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RfrsActionPerformed(evt);
            }
        });

        category.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        category.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Food", "Drinks" }));

        idTxt.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N

        cus.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(category, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Bck, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(Hme, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(txtSrc, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Src, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(quan, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(idTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(aDD, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Rmv, javax.swing.GroupLayout.DEFAULT_SIZE, 97, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(Rfrs, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cus, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(aDD, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Rmv, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Rfrs, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Hme, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Bck, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Src, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtSrc, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(quan, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(idTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(category, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        srcTable.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        srcTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Price"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane5.setViewportView(srcTable);

        jSeparator5.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jPanel13.setBackground(new java.awt.Color(255, 102, 0));

        sbmt.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        sbmt.setText("Submit");
        sbmt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sbmtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(sbmt, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(51, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(98, 98, 98)
                .addComponent(sbmt)
                .addContainerGap(126, Short.MAX_VALUE))
        );

        customer.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        customer.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Customer ID", "Status", "Total Price"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane7.setViewportView(customer);

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel15Layout.createSequentialGroup()
                                .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(502, 502, 502)))
                        .addGap(19, 19, 19))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jSeparator4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 703, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 458, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jPanel11, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel15Layout.createSequentialGroup()
                                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(34, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(49, 49, 49))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(29, 29, 29)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jSeparator5)
                    .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(173, Short.MAX_VALUE))
        );

        jScrollPane6.setViewportView(jPanel15);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 615, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.setExtendedState(takeOrder.ICONIFIED);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void BckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BckActionPerformed
        manager m = new manager();
        m.setVisible(true);
        dispose();
    }//GEN-LAST:event_BckActionPerformed

    private void HmeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HmeActionPerformed
        Access ac = new Access();
        ac.setVisible(true);
        dispose();
    }//GEN-LAST:event_HmeActionPerformed

    private void foodBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_foodBtnActionPerformed
        showInTable("Food");
        txtSrc.setEnabled(true);
        Src.setEnabled(true);
        quan.setEnabled(true);
        aDD.setEnabled(true);
        Rmv.setEnabled(true);
    }//GEN-LAST:event_foodBtnActionPerformed

    private void drinksBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drinksBtnActionPerformed
        showInTable("Drinks");
        
        txtSrc.setEnabled(true);
        Src.setEnabled(true);
        quan.setEnabled(true);
        aDD.setEnabled(true);
        Rmv.setEnabled(true);
    }//GEN-LAST:event_drinksBtnActionPerformed

    private void txtSrcKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSrcKeyReleased

        
    }//GEN-LAST:event_txtSrcKeyReleased

    private void txtSrcKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSrcKeyPressed

    }//GEN-LAST:event_txtSrcKeyPressed

    private void SrcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SrcActionPerformed
        try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/restaurant management system","root","");
            if(category.getSelectedItem().equals("Food"))
            {
                //DefaultTableModel tab = (DefaultTableModel)fTable.getModel();
                //tab.setRowCount(0);
                ArrayList<foodTable> fl = new ArrayList<>();
                ps = con.prepareStatement("SELECT * FROM `food` WHERE `Name`=?");
                ps.setString(1, txtSrc.getText());
                rs = ps.executeQuery();
                
                while(rs.next())
                {
                    foodTable f = new foodTable(rs.getString("Food ID"), rs.getString("Name"), rs.getInt("Price"));
                    fl.add(f);
                }
                showSearchedFood(fl);
            }
            else
            {
                //DefaultTableModel tab = (DefaultTableModel)dTable.getModel();
                //tab.setRowCount(0);
                ArrayList<drinkTable> dl = new ArrayList<>();
                ps = con.prepareStatement("SELECT * FROM `drinks` WHERE `Name`=?");
                ps.setString(1, txtSrc.getText());
                rs = ps.executeQuery();
                
                while(rs.next())
                {
                    drinkTable d = new drinkTable(rs.getString("Drinks ID"), rs.getString("Name"), rs.getInt("Price"));
                    dl.add(d);
                }
                showSearchedDrinks(dl);
            }
            }catch (ClassNotFoundException ex) {
            Logger.getLogger(takeOrder.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
            Logger.getLogger(takeOrder.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_SrcActionPerformed

    private void aDDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aDDActionPerformed
        int q = Integer.parseInt(quan.getValue().toString());
   
        if(category.getSelectedItem().equals("Food"))
        {
            ArrayList<foodTable> fl = new ArrayList<>();
            foodTable fs;
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost/restaurant management system","root","");
                ps = con.prepareStatement("SELECT * FROM `food` WHERE `Food ID`=?");
                ps.setString(1, idTxt.getText());
                rs = ps.executeQuery();
                int totalP;
                
                
                while(rs.next())
                {
                    fs = new foodTable(rs.getString("Food ID"), rs.getString("Name"),rs.getInt("Price"));
                    totalP = q*fs.getPrice();
                    sum = sum+totalP;
                    tp = sum;
                    fdPrice = totalP;
                    fl.add(fs);
                    
                }
                showAddFood(fdPrice,fl);
            
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(takeOrder.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(takeOrder.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
        else
        {
            ArrayList<drinkTable> dl = new ArrayList<>();
            drinkTable ds;
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost/restaurant management system","root","");
                ps = con.prepareStatement("SELECT * FROM `drinks` WHERE `Drinks ID`=?");
                ps.setString(1, idTxt.getText());
                rs = ps.executeQuery();
                int totalP;
                
                
                while(rs.next())
                {
                    ds = new drinkTable(rs.getString("Drinks ID"),rs.getString("Name"),rs.getInt("Price"));
                    totalP = q*ds.getPrice();
                    sum = sum+totalP;
                    tp = sum;
                    fdPrice = totalP;
                    dl.add(ds);
                }
                showAddDrinks(fdPrice,dl);
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(takeOrder.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(takeOrder.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
 
    }//GEN-LAST:event_aDDActionPerformed

    private void RfrsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RfrsActionPerformed
        takeOrder to = new takeOrder();
        to.setVisible(true);
        dispose();
    }//GEN-LAST:event_RfrsActionPerformed

    private void sbmtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sbmtActionPerformed
        Object row[] = new Object[3];
        DefaultTableModel table = (DefaultTableModel)customer.getModel();
        
        row[0] = cus.getValue();
        row[1] = "Paid";
        row[2] = tp;
        own = own+tp;
        table.addRow(row);
        insertion(own);
        tp = 0;
        sum = 0;
    }//GEN-LAST:event_sbmtActionPerformed
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(takeOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(takeOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(takeOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(takeOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new takeOrder().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Bck;
    private javax.swing.JButton Hme;
    private javax.swing.JButton Rfrs;
    private javax.swing.JButton Rmv;
    private javax.swing.JButton Src;
    private javax.swing.JButton aDD;
    private javax.swing.JButton add;
    private javax.swing.JButton back;
    private javax.swing.JComboBox<String> category;
    private javax.swing.JSpinner cus;
    private javax.swing.JTable customer;
    private javax.swing.JTable dTable;
    private javax.swing.JButton drinksBtn;
    private javax.swing.JTable fTable;
    private javax.swing.JButton foodBtn;
    private javax.swing.JButton home;
    private javax.swing.JTextField idTxt;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JButton jStReg;
    private javax.swing.JButton jStReg1;
    private javax.swing.JTextField jdt;
    private javax.swing.JSpinner quan;
    private javax.swing.JSpinner quant;
    private javax.swing.JButton rfrs;
    private javax.swing.JButton rmv;
    private javax.swing.JButton sbmt;
    private javax.swing.JButton src;
    private javax.swing.JTextField srcF;
    private javax.swing.JTable srcTable;
    private javax.swing.JTextField txtSrc;
    // End of variables declaration//GEN-END:variables
}

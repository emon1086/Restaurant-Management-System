/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class foodTable {

    String fid, Name;
    int price;

    public foodTable(String fid, String Name, int price) {
        this.fid = fid;
        this.Name = Name;
        this.price = price;
    }
    
    public foodTable(int price)
    {
        this.price = price;
    }
    
    
    public void setFid(String fid) {
        this.fid = fid;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getFid() {
        return fid;
    }

    public String getName() {
        return Name;
    }

    public int getPrice() {
        return price;
    }
    
    
}

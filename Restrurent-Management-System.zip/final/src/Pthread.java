/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class Pthread {
    public static void main(String[] args) {
        NewJFrame nj = new NewJFrame();
        nj.setVisible(true);
        try{
            
            for(int i=0; i<=100; i++)
            {
                Thread.sleep(100);
                NewJFrame.percentage.setText(Integer.toString(i)+"%");
                NewJFrame.progressB.setValue(i);
                if(i == 100)
                {
                    NewJFrame.jLabel2.setText("Loading finished....");
                    Access ac = new Access();
                    
                    ac.setVisible(true);
                    nj.dispose();
                }
            }
            
        }catch(Exception e){
            
        }
    }
    
}
